a=input('Enter a number')
print(a)
