#Tuple is a list that is not modify data 
my_tuple=(1,2,3,4)
#print(my_tuple[0])   // 1
print(my_tuple)     # (1,2,3)

# use count(), function to count which number is repeat like that my_tuple.count(4)  // output 1

# use index function to check index like that my_tuple.index(4) //3

# when we can use len() function to find length count length len(my_tuple)  // 4