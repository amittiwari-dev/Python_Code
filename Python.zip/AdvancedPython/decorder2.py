#Decorator

def my_decorator(func):
    def warp_func():
        print('++++++++++')
        func()
        print('++++++++++')
    return warp_func
@my_decorator
def hello():
    print('helloeee')
@my_decorator     # here we can use this then first code of my_dedcoreder and run this function then run my_decoreder function
def bye():
    print('see you later')    # output :-
# ++++++++++
# see you later
# ++++++++++
hello()
bye()