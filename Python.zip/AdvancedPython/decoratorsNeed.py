# Decorator
from time import time
def performance(fn):
    def warpper(*args,**kawrgs):
        t1=time()
        result=fn(*args,**kawrgs)
        t2=time()
        print(f'took {t2-t1} ms')
        return result
    return warpper
@performance
def long_time():
    for i in range(10000):
        i*5
long_time()