#Decorator

def my_decorator(func):
    def warp_func(*x,**y):
        print('++++++++++')
        func(*x,**y)
        print('++++++++++')
    return warp_func
@my_decorator
def hello(greeting,emoji=' 😍😍'):
    print(greeting , emoji)
@my_decorator     # here we can use this then first code of my_dedcoreder and run this function then run my_decoreder function
def bye():
    print('see you later')    # output :-
# ++++++++++
# see you later
# ++++++++++
a=input('Enter a Msg :- ')
b=input('Enter a emoji :- ')
hello(a,b)