def hello():
    print('hello, Amit')
greet=hello
print(greet)   # get address
print(greet())  # getting data
