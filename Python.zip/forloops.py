for item in 'Amit Tiwari':
    print(item)
for data in (1,2,3,4,5,6):
    print(data)