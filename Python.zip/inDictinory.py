dictionary={
    123:['Amit',1,2],
    'ram':1020,
    'hello123':True,
    True:'Demo Testing'
}
print('size' in dictionary)  #it will check for size key  exists then true or  not is key or exist then it will return false it 

#if i am clear all data then we can use dictionary.clear() then clear all data

# .copy is used to copy all data other variable.
# pop function is used to remove data in last
#popitem() function is used to random data remove


#update() function is used to update data inside the dictionary like that user.update({'ages':55})