user={
    'name':'Amit',
    'age':55,
    'can_swin':False,
}
for item in user.items():
    print(item)  #output ('name':'Amit')
    #('age':'55')
    #('can_swin':False)
for item in user.values():
    print(item) 
    #output
    #amit
    #55
    #false
for item in user.keys():
    print(item)