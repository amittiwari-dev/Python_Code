class Play:
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def run(self):
        print("run")
    def speak(self):
        print(f'my name is {self.name}, and i am {self.age} years old')
player=Play('amit',21)
#print(player.speak())
