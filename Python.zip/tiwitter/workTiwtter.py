import tweepy
auth=tweepy.OAuthHandler("CwtPXA7zVcX955oQrabITOY8H","giNeTTjgyIxqlVBRh8Gk1qCbJCKdD5H2yUroqfJwjDFePkOOq6")
auth.set_access_token('1421725267442028544-I3mEXrneoTM4q4TqJtDafF1nOkDajK','zQbi8esVkexOZyc7jzThcWiGy8nxqfNAvnBk3Fju5KRnb')
api = tweepy.API(auth)


# public_tweets=api.home_timeline()
# for tweet in public_tweets:
#     print(tweet.text)      # work old version
