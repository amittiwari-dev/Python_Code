my_set={1,2,3,4,5}
my_set.add(100) # add data in last of set
my_set.add(2) # here can not add 2 because 2 is already exist set is unique item collection

#copy function is used to copy all data in new variable but remove duplicate data 