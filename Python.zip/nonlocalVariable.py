def outer():
    x="local"
    def inner():
        nonlocal x #if we can use nonlocal then it will define variable as global variable
        x="nonlocal"
        print("inner:",x)
    inner()
    print("outer:",x)
outer()