from twilio.rest import Client
account_sid='AC778ac926d73eb7c08cea3cf7747fdd06'
auth_token='################################ auth token'
client=Client(account_sid,auth_token)
message=client.messages.create(
    from_='+919517462621',
    body='I CANT BELIEVE THIS WORKS',
    to='+916394215435'
)
print(message)