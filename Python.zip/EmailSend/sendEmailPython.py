import smtplib
from email.message import EmailMessage
email=EmailMessage()
email['from']='Computercodingclasses4 For Python Developer'
email['to']='a80625035@gmail.com'
email['subject']='Invite to develop my python project'
email.set_content('Hi! Kunal Bhai. How are you? This side from amit tiwari')
with smtplib.SMTP(host='smtp.gmail.com',port=587) as smtp:
    smtp.ehlo()
    smtp.starttls()
    smtp.login('ak9517462621@gmail.com','csebyhccssfypmgq')
    smtp.send_message(email)
    print('All good Boss!')



# cseb yhcc ssfy pmgq