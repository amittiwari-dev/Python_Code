# map , filter ,zip , and reduce

# def multiple_by2(li):
#     new_list=[]
#     for item in li:
#         new_list.append(item*2)
#     return new_list
# print(map(multiple_by2,[1,2,3]))   # given memory location
# print(multiple_by2([1,2,3]))


my_list=[1,2,3]
def multiple_by(item):
    return item*2
print(list(map(multiple_by,my_list)))  # here this code not affect our old data is a pure function
print(my_list)