some_list=['a','b','c','d','d','a','n','n']
duplicate=[]
for value in some_list:
    if some_list.count(value) > 1:
        if(value not in duplicate):
            duplicate.append(value)
print(duplicate)
duplicate1=[];

new_list=list(set([x for x in some_list if some_list.count(x) >1  ]))
print(new_list)