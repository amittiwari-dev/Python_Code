from PIL import Image , ImageFilter
img =Image.open('a1.jpg')
# print(img.format)  # this is return format
# print(img.size)  # this is return size
# print(img.mode) # this is return img color

filter_img=img.filter(ImageFilter.BLUR);  #use for images blur
filter_img.save("blur.png",'png')   # use for save file blur.png inside the work directly
