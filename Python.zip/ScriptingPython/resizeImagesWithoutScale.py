from PIL import Image , ImageFilter
img =Image.open('a2.jpg')
# print(img.format)  # this is return format
#print(img.size)  # this is return size
# print(img.mode) # this is return img color
img.thumbnail((200,100))
img.save('thumbnail.jpg')

img.show()