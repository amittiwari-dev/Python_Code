from PIL import Image , ImageFilter
img =Image.open('a2.jpg')
# print(img.format)  # this is return format
# print(img.size)  # this is return size
# print(img.mode) # this is return img color

filter_img=img.convert('L');  # use for images black and white
box=(100,100,400,400)
saveImages=filter_img.crop(box)
saveImages.save("cropImages.png",'png')

