from PIL import Image , ImageFilter
img =Image.open('a1.jpg')
# print(img.format)  # this is return format
# print(img.size)  # this is return size
# print(img.mode) # this is return img color

filter_img=img.convert('L');  # use for images black and white

filter_img.save("blackWhite.png",'png')

rotate=filter_img.rotate(90)  # here i can do image rotate then save images
rotate.save('rotateImages.png','png')
rotate.show() # it will show images
