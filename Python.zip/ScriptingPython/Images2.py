from PIL import Image , ImageFilter
img =Image.open('a1.jpg')
# print(img.format)  # this is return format
# print(img.size)  # this is return size
# print(img.mode) # this is return img color

filter_img=img.filter(ImageFilter.SMOOTH);  # use for smooth images i cna use SHARP to sharp images

filter_img.save("smooth.png",'png')
