import requests
import hashlib
def request_api(query_char):
    url = 'https://api.pwnedpasswords.com/range/' + query_char
    res = requests.get(url)
    if res.status_code !=200:
        raise RuntimeError(f'Error Fetching:{res.status_code}, check the api and try again')
    return res
def read_Res(response):
    print(response.text)
def pwned_api(password):
    #check password if it exists in API Response
    sha1password=hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    first5_char,tail=sha1password[:5],sha1password[5:]
    response=request_api(first5_char)
    print(first5_char,tail)
    print(response)
    return  read_Res(response)

pwned_api("123")