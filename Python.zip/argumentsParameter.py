# parameter
def say_hello(name,age):
    print(f'Hi {name} you are {age} year old')
#arguments
say_hello('Amit',21)