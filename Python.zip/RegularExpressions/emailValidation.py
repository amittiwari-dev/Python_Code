import re
pattern =re.compile(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)")
string ='Amit@bhjjhj.vcokm'
a=pattern.search(string)
check=pattern.fullmatch(string)
print(check)
#at least 8 char long
#contain any sort letters, number