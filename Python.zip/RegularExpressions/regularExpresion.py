import re
string = 'Search inside of this text plz!'
print('search' in string)  # false
print('Search' in string)  # true
a=re.search('this',string)
print(re.search('this',string))
print(a.span())  # string and ending index return
print(a.end())  # it is retunrn ending index
print(a.start())  # it is retunrn starting index
print(a.group()) # if value is one time thenn given index if value is multiple time then it will return searching value
