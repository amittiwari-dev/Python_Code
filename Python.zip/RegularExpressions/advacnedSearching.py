import re
pattern=re.compile('this')
string='search this inside of this text plz!'

a=pattern.search(string)
b=pattern.findall(string)  # it will return the list of match string
c=pattern.fullmatch(string) # it return only all string is match then output object match otherwise it will retunr none

print(c)

print(b)