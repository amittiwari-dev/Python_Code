#OOPS Start
class PlayerCharacter:
    def __init__(self,name):
        self.name=name # attributes
def run(self):
    print('Run')

player1=PlayerCharacter('Amit')
print(player1.name) # attributes getting using .and attributies name
