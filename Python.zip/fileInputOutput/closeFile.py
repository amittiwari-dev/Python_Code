with open('textPython.txt',mode='a') as my_file:
     text=my_file.write('Hey! i am fine ')  #this code for write the msg inside the textPythin file
   # print(my_file.readlines())
#mode
#a :- append       # it is only write and save privious data and new data
#r+ :- read write    store previous data and write all data which is given by my
#w :- only write     all previous data will be remove and write new data