try:
    with open('textPyhon.txt',mode='r') as my_file:
        print(my_file.read())
except FileNotFoundError as error:
    print('Hey! File not found! plz enter a right path')
    raise error