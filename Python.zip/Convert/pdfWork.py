import PyPDF2

# with open('dummy.pdf','rb') as file: # rb means read binary
#     reder=PyPDF2.PdfReader(file)
#     print(reder.pages)
template = PyPDF2.PdfReader(open('dummy.pdf', 'rb'))
watermark = PyPDF2.PdfReader(open('Django_Project.pdf', 'rb'))
output = PyPDF2.PdfWriter()

for i in range(len(template.pages)):
    page = template.pages[i]
    page.merge_page(watermark.pages[0])
    output.add_page(page)

with open('watermaked_output.pdf', 'wb') as outputFile:
    output.write(outputFile)