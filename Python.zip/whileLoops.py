i=0
while i<55:
    print(i)
    i+=1