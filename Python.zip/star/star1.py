for x in range(0,5):
    for x in range(0,5):
        print("*",end="")
    print(" ")