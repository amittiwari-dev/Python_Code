# ******
# *****
# ****
# ***
# **
# *

for x in range(0,6):
    for y in range(x,6):
        print("*",end="")
    print(" ")