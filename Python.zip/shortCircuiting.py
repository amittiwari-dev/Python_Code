#Short Circuiting
is_Friend=False
is_user=True
if is_Friend and is_user:
    print('best friends forever')