def highest_even(li):
    evens=[]
    for item in li:
        if item % 2==0:
            evens.append(item)
    return max(evens)
print(highest_even([10,20,50,82,0,5,77,99,66,100]))