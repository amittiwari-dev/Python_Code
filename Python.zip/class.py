class Play:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def run(self):
        print("run")
player=Play('amit',22)
print(player.name)
print(player.age)