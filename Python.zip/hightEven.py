def highest_even(li):
    number=0
    for x in li:
        if x%2==0:
            if(number < x):
                number=x
    return number 

print(highest_even([1,2,3,4,8,11]))