
# > **_Write a program which can compute the factorial of a given numbers.The results should be printed in a comma-separated sequence on a single line.Suppose the following input is supplied to the program: 8
# > Then, the output should be:40320_**
number=int(input('Enter a number :) '))
result=number
for x in range(number):
    data=number-(x+1)
    if(data !=0):
        result=result * data
        print(result)
