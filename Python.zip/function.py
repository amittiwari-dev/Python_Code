def say_hello():
    print('Hi, Amit')
say_hello()