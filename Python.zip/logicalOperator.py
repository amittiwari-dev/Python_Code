# and or(and not) and not is logical operator
a=input('Enter a number')
b=input('Enter a number')
if(a=='5' and b=='5'):
    print('And Operator')
elif(a=='4' or b=='5'):
    print('Or operator')
else:
    print('Condition or not define')

    