picture=[
    [0,0,0,1,0,0,0],
    [0,0,1,1,1,0,0],
    [0,1,1,1,1,1,0],
    [1,1,1,1,1,1,1],
    [0,0,0,1,0,0,0],
    [0,0,0,1,0,0,0],
]
for image in picture:
    for pix in image:
        if(pix == 1):
            print('*' , end='')
        else:
            print(' ',end='')
    print('')