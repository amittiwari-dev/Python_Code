import datetime
print(datetime.time(5,21,10))
print(datetime.date.today())