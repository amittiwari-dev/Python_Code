from random import randint

import random
#generate a number 1 -10
answer=randint(1,10)

#check that input is a number 1-10
while True:
    try:
        # input form user
      guess = input('Guess a number 1 to 10 : ')
      if int(guess) > 1 and int(guess) < 11:
          if int(guess)==answer:
              print('Well Done Guessing Number is corrent')
              break
      else:
          print('Hey Bro, I said 1~10')
    except ValueError:
        print('plz Enter a number')
        continue

#check if number is the right guess. Otherwise

#ask again