import  pyjokes

joke=pyjokes.get_joke('en','all')
print(joke)