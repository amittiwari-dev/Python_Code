import  random
print(random.randrange(1,10,1))
print(random.randint(1,10))
print(random.choice([1,2,3,4,5,6]))
my_list=[1,2,3]

random.shuffle(my_list)
print(my_list)