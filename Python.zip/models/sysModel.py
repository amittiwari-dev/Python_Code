import  sys
sys.argv