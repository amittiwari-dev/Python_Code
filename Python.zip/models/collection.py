from collections import Counter, defaultdict ,OrderedDict
list_1=[1,2,2,2,2,2,2,2,2,3,4,5,6,7]
print(Counter(list_1))   # this is return the data how many type return value

dictionary=defaultdict(lambda:'does not exist',{'a':1,'b':2})
print(dictionary['c'])