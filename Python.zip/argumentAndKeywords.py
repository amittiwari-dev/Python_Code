# *args **kwargs
def super_fun(*args):
    print(args)
    return sum(args)
print(super_fun(10,20,50,60)) # output of all sum