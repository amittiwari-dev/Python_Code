class SuperLis(list):
    def __len__(self):
        return 1000
super_List1=SuperLis();
print(len(super_List1))
super_List1.append(5)
print(super_List1[0])