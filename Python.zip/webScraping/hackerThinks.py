import requests
from bs4 import  BeautifulSoup
res=requests.get('https://www.axisbank.com/')
print(res.text)