import requests
from bs4 import  BeautifulSoup
res=requests.get('https://www.sarkariresult.com/')
soup=BeautifulSoup(res.text,'html.parser')

# print(soup.body.contents)  # it will show body contents with array format
# print(soup.body)  # it will show only body tag inside all code
# print(soup.find_all('TagName'))  # it will show all data which tag will be given
# print(soup) # it will show all data starting to end
#print(soup.title) # it will return the title of given website
# print(soup.a) # it will given first a tag
# print(soup.find('TagName')) # it will given the only first tag which it will given
#print(soup.select('.nav'))  # it will show the data of selector of css



