import unittest
class TestGame(unittest.TestCase):
    def test_input(self):
        pass

