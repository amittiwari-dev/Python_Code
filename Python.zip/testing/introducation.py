#pylint
#pyflakes
#AutoPEP 8
#PEP 8
import unittest
import simpleCodeTesting
class testing_code(unittest.TestCase):

    def test_do_stuff(self):
        num = 10
        result=simpleCodeTesting.do_staff(num)
        self.assertEqual(result,15)

    def test_do_stuff2(self):
        num = 'amit'
        result=simpleCodeTesting.do_staff(num)
        self.assertIsInstance(result,ValueError)

    def test_do_staff3(self):
        num= None
        result = simpleCodeTesting.do_staff(num)
        self.assertEqual(result, 'Plz Enter a number')

