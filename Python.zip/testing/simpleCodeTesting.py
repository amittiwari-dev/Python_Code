def do_staff(num):
    try:
        if num:
         return int(num) + 5
        else:
            return 'Plz Enter a number'
    except ValueError as err:
        return err
