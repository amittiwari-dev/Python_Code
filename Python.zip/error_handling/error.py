# print(1+'Hello')  #TypeError
print(1+True)  # Output 2
#error Handling
try:
    age=int(input('What is your age ? '))
    print(age)
except:
    print('Plz Enter Valid Age')
else:
    print('thank you!')