while True:
    try:
        age=int(input('What is your age ? '))
        10/age
        raise ValueError('Hey cut it out')
    # except ValueError:
    #     print('Please enter a  number : ')
    #     continue
    except ZeroDivisionError:
        print('plz enter age higher than 0')
        break
    else:
        print('Thank you!!')
    finally:
        print('ok, i am finally done')
    print('can you hear me?')