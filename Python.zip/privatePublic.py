class play:
    def __init__(self,name,age,name1):
        self._name=name  # if we can use _ then it will private variable
        self._age=age
        self.name=name1
    def run(self):
        print('Code is running')
    def speak(self):
        print(f'my name is {self._name} this is {self.name}')
player=play('amit',21,'Kumar')
print(player.speak())