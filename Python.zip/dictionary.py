dictionary={
    123:['Amit',1,2],
    'ram':1020,
    'hello123':True,
    True:'Demo Testing'
}
print(dictionary[True])