# when we can use method then we can use . and method name
def test(a):
    '''
    Info: this function test and check 
    '''
    print(a)
help(test)
print(test.__doc__)