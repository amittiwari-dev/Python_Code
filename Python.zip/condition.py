old=False
is_licenced=False

if old:
    print('You are old enough to drive!')
elif is_licenced:
    print('You can Drive Now!')
else:
    print('You are not of age!')
print('Oky')