def is_odd_or_even(num):
    if(num %2==0):
        return True
    else:
        return False
    
print(is_odd_or_even(44))