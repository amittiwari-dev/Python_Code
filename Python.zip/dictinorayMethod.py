#dictionary
user={
   
    'ram':[1,2,3,4],
    'demo':'True',
#    'age':55
    
}
print(user.get('age'))
# if we can not create age key then it will return none not given error

#print(user['age']) #but this is given error age is not define 
 
#when we are create a dist
user2=dict(name='Amit')  # here we can create a dictonary 
print(user2) 