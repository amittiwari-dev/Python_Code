def buy(item):
    cart=[]
    cart.append(item)
    return cart