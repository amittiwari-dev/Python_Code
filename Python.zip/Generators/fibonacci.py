def fibon(number):
    a=1;
    b=2;
    for i in range(number):
        yield a
        temp=a
        a=b
        b=temp+b
for x in fibon(20):
    print(x)