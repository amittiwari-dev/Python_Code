import functionClass
print(functionClass.divide(10,2))