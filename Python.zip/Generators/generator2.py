#interable
#iterate
#generators

def make_list(num):
    result=[]
    for i in range(num):
        result.append(i*2)
    return result
my_list = make_list(100)
print(list(range(10000)))


def generator_function(num):
    for i in range(num):
        yield  i*2
g=generator_function(100)
print(next(g))  # return 0
print(g)     # resturn address