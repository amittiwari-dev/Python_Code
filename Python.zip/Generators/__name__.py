print(__name__);
if __name__ == '__main__':  # here code only run when this page run if any page import this then it will not run code inside the if condition
    print('Pleasr run this')