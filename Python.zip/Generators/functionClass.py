def multiple(num1,num2):
    return num1*num2
def divide(num1,num2):
    return num1/num2