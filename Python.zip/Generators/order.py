import shopping
print(shopping.buy(['shirt','pen','book']))
 