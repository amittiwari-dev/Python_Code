class User(object):
    def sign_in(self):
        print('logged in')
    def attack(self):
        print('do nothing')
class Wizard(User):
    def __int__(self,name,power):
        self.name=name,
        self.power=power
    def attack(self):
        User.attack(self)
        print(f'attacking with power {self.power}')
class Archer(User):
    def __init__(self,name,num_arrows):
        self.name=name,
        self.num_arrows=num_arrows
    def attack(self):
        print(f'attacking with arrows : arrows left - {self.nu_arrows}')

winzard1=Wizard('Amit',60)
archer1=Archer('Robin',30)
print(winzard1.attack())
print(archer1)