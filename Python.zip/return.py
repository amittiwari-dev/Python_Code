def sum(num1,num2):
   return num1 + num2
print(sum(4,5))