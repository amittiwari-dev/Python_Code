class User():
    def sign_up(self):
        print('logged in')
class Winzard(User):
   pass
class Archer(User):
    def __init__(self,name,power):
        self.name=name
        self.power=power
    def attack(self):
        print(f'attacking with power of {self.power}') 
wizard1=Winzard()
arch=Archer('Amit',21)
print(arch.attack())