# a='Hello amit'
# if((n := len(a)) > 10):
#     print(f"to long {n} elements")
# this code run only 3.8 above version
#because my python is 3.7 then it will not run  given error
